#!/usr/bin/env python3
"""
Ballistic Pendulum Tracker — Red-bob + White-mass fallback
==========================================================
Tracks the pendulum through the video, computes max displacement,
instantaneous speed, acceleration, kinetic energy, and momentum.
"""

import argparse
import sys
from pathlib import Path

import cv2
import numpy as np


# ----------------------------------------------------------------------
# Detection
# ----------------------------------------------------------------------
def detect_pendulum(frame: np.ndarray, debug_mask: np.ndarray | None = None):
    """
    Detect the pendulum bob / mass in *frame*.
    Returns (cx, cy, mask) or (None, None, mask) on failure.
    """
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # --- White mask (hard-hat + bag) ---------------------------------
    lower_white = np.array([0, 0, 140])
    upper_white = np.array([180, 55, 255])
    mask_white = cv2.inRange(hsv, lower_white, upper_white)

    # --- Red mask (plastic bob) --------------------------------------
    lower_red1 = np.array([0, 80, 80])
    upper_red1 = np.array([12, 255, 255])
    lower_red2 = np.array([168, 80, 80])
    upper_red2 = np.array([180, 255, 255])
    mask_red = cv2.bitwise_or(
        cv2.inRange(hsv, lower_red1, upper_red1),
        cv2.inRange(hsv, lower_red2, upper_red2),
    )

    # Combine: we want the whole pendulum mass
    mask = cv2.bitwise_or(mask_white, mask_red)

    # Morphological clean-up
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (7, 7))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel, iterations=1)

    if debug_mask is not None:
        debug_mask[:] = mask

    # Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    if not contours:
        return None, None, mask

    # Keep only sensibly-large blobs
    min_area = 800
    valid = [c for c in contours if cv2.contourArea(c) >= min_area]
    if not valid:
        return None, None, mask

    # Largest blob = pendulum mass
    largest = max(valid, key=cv2.contourArea)
    M = cv2.moments(largest)
    if M["m00"] == 0:
        return None, None, mask

    cx = float(M["m10"] / M["m00"])
    cy = float(M["m01"] / M["m00"])
    return cx, cy, mask


# ----------------------------------------------------------------------
# Signal helpers
# ----------------------------------------------------------------------
def smooth_gaussian_1d(x: np.ndarray, sigma: float = 1.5) -> np.ndarray:
    """1-D Gaussian smoothing via OpenCV."""
    if sigma <= 0 or len(x) < 3:
        return x
    row = x.reshape(1, -1).astype(np.float32)
    ks = max(3, int(4 * sigma) | 1)
    blurred = cv2.GaussianBlur(row, (ks, 1), sigmaX=sigma)
    return blurred.ravel()


def fill_missing(y: np.ndarray) -> np.ndarray:
    """Linear interpolation across NaNs."""
    out = y.copy()
    nans = np.isnan(out)
    if not nans.any():
        return out
    valid = ~nans
    if valid.sum() < 2:
        return out
    idx = np.arange(len(out))
    out[nans] = np.interp(idx[nans], idx[valid], out[valid])
    return out


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(description="Track ballistic pendulum and compute kinematics.")
    parser.add_argument(
        "--video",
        type=str,
        default="myVid.mp4",
        help="Input video path (default: myVid.mp4).",
    )
    parser.add_argument(
        "--string-px",
        type=float,
        default=None,
        help="Length of the 40 cm string measured in pixels (rest frame).",
    )
    parser.add_argument(
        "--output",
        type=str,
        default="output_tracked.mp4",
        help="Optional path to write an annotated MP4.",
    )
    parser.add_argument(
        "--show",
        action="store_true",
        help="Show live tracking window.",
    )
    parser.add_argument(
        "--warmup",
        type=int,
        default=5,
        help="Frames to average for the rest centroid.",
    )
    parser.add_argument(
        "--smooth",
        type=float,
        default=2.0,
        help="Gaussian smoothing sigma (frames) applied to position before differentiation.",
    )
    args = parser.parse_args()

    vid_path = Path(args.video)
    if not vid_path.exists():
        print(f"Error: file not found: {vid_path}", file=sys.stderr)
        sys.exit(1)

    cap = cv2.VideoCapture(str(vid_path))
    if not cap.isOpened():
        print("Error: cannot open video.", file=sys.stderr)
        sys.exit(1)

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
    w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    dt = 1.0 / fps
    print(f"Video: {w}x{h} @ {fps:.2f} fps (dt = {dt*1000:.1f} ms)")

    writer = None
    if args.output:
        fourcc = cv2.VideoWriter_fourcc(*"mp4v")
        writer = cv2.VideoWriter(args.output, fourcc, fps, (w, h))

    # Pendulum physical properties specified by user
    mass_kg = 1501.0 / 1000.0  # 1501 g converted to kg

    # ------------------------------------------------------------------
    # First pass: collect raw centroids
    # ------------------------------------------------------------------
    positions = []
    frames = []
    frame_idx = 0

    print("Pass 1/2: tracking…")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        frames.append(frame)

        cx, cy, mask = detect_pendulum(frame)
        if cx is None:
            positions.append((np.nan, np.nan))
        else:
            positions.append((cx, cy))

        frame_idx += 1
        if frame_idx % 30 == 0:
            print(f" processed {frame_idx} frames…")

    cap.release()
    positions = np.array(positions, dtype=float)
    n = len(positions)

    if n < args.warmup + 10:
        print("Error: too few frames.", file=sys.stderr)
        sys.exit(1)

    # ------------------------------------------------------------------
    # Rest position
    # ------------------------------------------------------------------
    warmup_pts = positions[: args.warmup]
    valid_warmup = warmup_pts[~np.isnan(warmup_pts).any(axis=1)]
    if len(valid_warmup) == 0:
        print("Error: no detection during warmup.", file=sys.stderr)
        sys.exit(1)

    rest = valid_warmup.mean(axis=0)
    print(f"\nRest centroid (avg of first {len(valid_warmup)} frames): "
          f"({rest[0]:.1f}, {rest[1]:.1f}) px")

    # ------------------------------------------------------------------
    # Auto-estimate string length in pixels if user didn't supply it
    # ------------------------------------------------------------------
    string_px = args.string_px
    if string_px is None:
        string_px = rest[1] * 0.65
        print(f"Auto-estimated string length: ~{string_px:.0f} px "
              f"(supply --string-px for exact scale)")

    scale_m_per_px = 0.40 / string_px  # 40 cm physical string
    print(f"Scale: {scale_m_per_px*100:.4f} cm/px = {1/scale_m_per_px:.1f} px/m")

    # ------------------------------------------------------------------
    # Interpolate missing detections, then smooth
    # ------------------------------------------------------------------
    x_raw = fill_missing(positions[:, 0])
    y_raw = fill_missing(positions[:, 1])

    x = smooth_gaussian_1d(x_raw, sigma=args.smooth)
    y = smooth_gaussian_1d(y_raw, sigma=args.smooth)

    # Displacement from rest
    dx = x - rest[0]
    dy = y - rest[1]
    disp_px = np.hypot(dx, dy)
    disp_m = disp_px * scale_m_per_px

    # Angle from vertical
    horiz_px = np.abs(dx)
    sin_theta = np.clip(horiz_px / string_px, 0, 1)
    theta = np.arcsin(sin_theta)
    theta_deg = np.degrees(theta)

    # ------------------------------------------------------------------
    # Kinematics: velocity, acceleration, kinetic energy, momentum
    # ------------------------------------------------------------------
    vx = np.gradient(x, dt)
    vy = np.gradient(y, dt)
    speed_px_s = np.hypot(vx, vy)
    speed_m_s = speed_px_s * scale_m_per_px

    ax = np.gradient(vx, dt)
    ay = np.gradient(vy, dt)
    accel_px_s2 = np.hypot(ax, ay)
    accel_m_s2 = accel_px_s2 * scale_m_per_px

    # Kinetic Energy: KE = 0.5 * m * v^2 (Joules)
    kinetic_energy = 0.5 * mass_kg * (speed_m_s ** 2)

    # Momentum magnitude: p = m * v (kg * m/s)
    momentum = mass_kg * speed_m_s

    # ------------------------------------------------------------------
    # Extract maxima
    # ------------------------------------------------------------------
    max_disp_idx = int(np.argmax(disp_px))
    max_speed_idx = int(np.argmax(speed_m_s))
    max_accel_idx = int(np.argmax(accel_m_s2))
    max_ke_idx = int(np.argmax(kinetic_energy))
    max_mom_idx = int(np.argmax(momentum))

    max_disp_px = disp_px[max_disp_idx]
    max_disp_m = disp_m[max_disp_idx]
    max_angle_deg = theta_deg[max_disp_idx]

    max_speed_m_s = speed_m_s[max_speed_idx]
    max_accel_m_s2 = accel_m_s2[max_accel_idx]
    max_ke = kinetic_energy[max_ke_idx]
    max_mom = momentum[max_mom_idx]

    # ------------------------------------------------------------------
    # Print report
    # ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("RESULTS")
    print("=" * 60)
    print(f"Total frames: {n}")
    print(f"Pendulum Mass: {mass_kg * 1000:.1f} g")
    print(f"String length (px): {string_px:.1f}")
    print(f"Scale: {scale_m_per_px*100:.3f} cm/px")
    print("-" * 60)
    print(f"Max displacement: {max_disp_px:.1f} px = {max_disp_m*100:.2f} cm")
    print(f" → at frame: {max_disp_idx} (time: {max_disp_idx*dt:.3f} s)")
    print(f" → swing angle: {max_angle_deg:.2f}° from vertical")
    print("-" * 60)
    print(f"Max speed: {max_speed_m_s:.3f} m/s ({max_speed_m_s*100:.2f} cm/s)")
    print(f" → at frame: {max_speed_idx} (time: {max_speed_idx*dt:.3f} s)")
    print("-" * 60)
    print(f"Max acceleration: {max_accel_m_s2:.3f} m/s²")
    print(f" → at frame: {max_accel_idx} (time: {max_accel_idx*dt:.3f} s)")
    print("-" * 60)
    print(f"Max Kinetic Energy: {max_ke:.4f} J")
    print(f" → at frame: {max_ke_idx} (time: {max_ke_idx*dt:.3f} s)")
    print("-" * 60)
    print(f"Max Momentum: {max_mom:.4f} kg·m/s")
    print(f" → at frame: {max_mom_idx} (time: {max_mom_idx*dt:.3f} s)")
    print("=" * 60)

    # ------------------------------------------------------------------
    # Second pass: draw annotations
    # ------------------------------------------------------------------
    if args.output or args.show:
        print("\nPass 2/2: annotating…")
        for i, frame in enumerate(frames):
            ann = frame.copy()

            # Rest position marker
            cv2.circle(ann, (int(rest[0]), int(rest[1])), 6, (0, 255, 0), -1)

            # Current centroid
            if not np.isnan(x[i]):
                cv2.circle(ann, (int(x[i]), int(y[i])), 6, (0, 0, 255), -1)
                cv2.line(ann,
                         (int(rest[0]), int(rest[1])),
                         (int(x[i]), int(y[i])),
                         (255, 0, 0), 2)

            # Overlay text
            texts = [
                f"disp: {disp_px[i]:.1f} px ({disp_m[i]*100:.1f} cm)",
                f"spd: {speed_m_s[i]:.2f} m/s",
                f"acc: {accel_m_s2[i]:.2f} m/s2",
                f"KE: {kinetic_energy[i]:.3f} J",
                f"Mom: {momentum[i]:.3f} kg*m/s",
                f"ang: {theta_deg[i]:.1f} deg",
            ]
            y0 = 30
            for j, txt in enumerate(texts):
                cv2.putText(ann, txt, (10, y0 + j*25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 0, 0), 3)
                cv2.putText(ann, txt, (10, y0 + j*25),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)

            if writer:
                writer.write(ann)
            if args.show:
                cv2.imshow("Tracking", ann)
                if cv2.waitKey(int(dt * 1000)) & 0xFF == ord("q"):
                    break

    if writer:
        writer.release()
    cv2.destroyAllWindows()
    print(f"Annotated video saved to: {args.output}" if args.output else "Done.")


if __name__ == "__main__":
    main()