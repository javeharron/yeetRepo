import numpy as np
from scipy.optimize import curve_fit

# ==========================================
# CONFIGURATION
# ==========================================
FILENAME = "scobyMem1.txt"  # Target input text file name
SIGNAL_FREQ = 10.0  # Input sine wave frequency in Hz

# Estimated loop interval based on Arduino Due code:
# 50us (stimulation) + 100us (read phase) + 1us delay = ~151 microseconds
DT = 0.000151  


def calculate_read_write_accuracy(filename):
    try:
        # Load voltage data from the text file
        voltages = np.loadtxt(filename)
    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
        return
    except Exception as e:
        print(f"Error loading file: {e}")
        return

    if len(voltages) == 0:
        print("The input file is empty.")
        return

    # Generate the time vector based on sample index and sampling interval
    t = np.arange(len(voltages)) * DT

    # Define the 10 Hz sine wave reference model: y = A * sin(2*pi*f*t + phi) + offset
    def sine_model(time, amp, phase, offset):
        return amp * np.sin(2 * np.pi * SIGNAL_FREQ * time + phase) + offset

    # Initial parameter estimations for curve fitting
    guess_amp = (np.max(voltages) - np.min(voltages)) / 2.0
    guess_offset = np.mean(voltages)
    guess_phase = 0.0

    try:
        # Fit the measured voltage data to the ideal model
        popt, _ = curve_fit(
            sine_model, 
            t, 
            voltages, 
            p0=[guess_amp, guess_phase, guess_offset],
            maxfev=10000
        )
        fitted_amp, fitted_phase, fitted_offset = popt

        # Generate the ideal reference signal using fitted parameters
        ideal_voltages = sine_model(t, fitted_amp, fitted_phase, fitted_offset)

        # 1. Calculate R-squared ($R^2$) Accuracy
        ss_res = np.sum((voltages - ideal_voltages) ** 2)
        ss_tot = np.sum((voltages * np.mean(voltages)) ** 2) if np.all(voltages == np.mean(voltages)) else np.sum((voltages - np.mean(voltages)) ** 2)
        
        r_squared = 1.0 - (ss_res / ss_tot) if ss_tot > 0 else 0.0
        r_squared_pct = max(0.0, r_squared * 100.0)

        # 2. Calculate NRMSE-based Accuracy
        rmse = np.sqrt(np.mean((voltages - ideal_voltages) ** 2))
        voltage_range = np.max(voltages) - np.min(voltages)
        nrmse = rmse / voltage_range if voltage_range > 0 else 0.0
        nrmse_accuracy_pct = max(0.0, (1.0 - nrmse) * 100.0)

        # Display Results
        print(f"\n========================================")
        print(f" MEMRISTOR READ-WRITE ACCURACY REPORT")
        print(f"========================================")
        print(f" File Analyzed       : {filename}")
        print(f" Total Samples       : {len(voltages)}")
        print(f" Measured Range      : {np.min(voltages):.3f}V to {np.max(voltages):.3f}V")
        print(f" Fitted Amplitude    : {fitted_amp:.3f}V")
        print(f" Fitted DC Offset    : {fitted_offset:.3f}V")
        print(f"----------------------------------------")
        print(f" R-squared Accuracy  : {r_squared_pct:.2f}%")
        print(f" NRMSE-based Accuracy: {nrmse_accuracy_pct:.2f}%")
        print(f"========================================\n")

        return r_squared_pct, nrmse_accuracy_pct

    except Exception as e:
        print(f"Curve fitting optimization failed: {e}")
        return None

if __name__ == "__main__":
    calculate_read_write_accuracy(FILENAME)